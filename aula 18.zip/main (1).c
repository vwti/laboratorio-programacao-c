#include <stdio.h>
float maiorpreco(float a, float b){
    if(a>b){
        return a;
    }else{
        return b;
    }
}
int main(void){
    float preco1, preco2;
    printf("digite o primeiro preco");
    scanf("%f, &preco1");
    printf("digite o segundo preco");
    scanf("%f, &preco1");
    if (preco1 == preco2){
        printf("os precos sao iguais\n");
    }else{
        printf("maior preco: %.2f\n", maiorpreco(preco1, preco2));
    }
    return 0;
}