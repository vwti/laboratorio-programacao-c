#include <stdio.h>
void exibirLinha(void){
    printf("*********\n");
}
int main (void){
    exibirLinha();
    printf("relatorio\n");
    exibirLinha();
    return 0;
}