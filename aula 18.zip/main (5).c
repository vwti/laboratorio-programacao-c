#include <stdio.h>
long long resultado =1;
int i;
for (i=1;i<= numero, i++){
    resultado = resultado*i;
}
return resultado;
}
int main(void)
int numero
printf("digite um numero de 0 a 12:");
scanf(%d, &numero);
while(numero<0||numero>12){
    printf("numero invalido digite novamente:");
    scanf("%d", & numero);
}
printf("fatorial de %d: %lld\n", numero,
calcularFatorial(numero);
return 0;
}