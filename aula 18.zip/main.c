#include <stdio.h>
void exibirMenu(void){
    printf("\n--- calculadora---\n");
    printf("1- somar\n");
    printf("2- subtrair\n");
    printf("3- multiplicar\n");
    printf("4- dividir\n");
    printf("5- sair\n");
}
 float somar(float a, float b){
    return a+b;
}
 float subtrair(float a, float b){
     return a-b;
 }
 float multiplicar(float a, float b){
     return a*b;
 }
 float dividir(float a, float b){
     return a/b;
 }
 int main(void){
     int opcao
     float n1, n2;
     do {
         exibirMenu();
         scanf("%d", &opcao);
         if(opcao>=1 && opcao<= 4){
             printf("digite o primeiro numero: ");
             scanf("%f", &n1);
             printf("digite o segundo numero: ")
             scanf("%f", &n2);
            
         }
     switch (opcao) {
         case 1:
         printf("Resultado: %.2f\n", somar(n1, n2));
         break;
         case 2:
         printf("Resultado %.2f\n", subtrair(n1,n2));
         break;
         case 3:
         printf("Resultado: %.2f\n", multiplicar(n1,n2));
         break;
         case 4:
         if (n2==0 {
             printf("erro: divisao por zero\n");
             else{
                 printf("resultado: %.2f\n", dividir(n1,n2));
                 break;
                case 5:
                printf("encerrando calculadora\n")
                break;
                default:
                printf("Opcao invalida\n);
             }
         } while (Opcao!=5);
         return 0;
             }