#include <stdio.h>
int dobro(int quantidade){
    return quantidade *2;
}
int main(void){
    int quantidade, resultado;
    printf("digite a quantidade inicial: ");
    scanf("%d", &quantidade);
    resultado = dobro(quantidade);
    printf("quantidade inicial: %d\n", quantidade);
    printf("quantidade final: %d\n", resultado);
    return 0;
}