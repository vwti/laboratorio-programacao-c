#include <stdio.h>
int verificarPar(int numero){
    if (numero%2==0){
        return 1;
    }else{
        return 0;
    }
}
int main(void){
    int numero;
    printf("digite um numero inteiro: ");
    scanf("%d",& numero);
    if (verificarPar(numero)==1){
        printf("o numero e par.\n");
    }else{
        printf("o numero e impar.\n");
    }
    return 0;
}