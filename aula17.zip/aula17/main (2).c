#include <stdio.h>
#include <string.h>

int main(void) {
    char nome[50], copia[50];
    char curso[10];
    char mensagem[100] = "Ola, ";

    printf("Digite o primeiro nome do estudante: ");
    scanf("%49s", nome);

    printf("Digite o codigo do curso (CC ou SI): ");
    scanf("%9s", curso);

    strcpy(copia, nome);
    strcat(mensagem, nome);
    strcat(mensagem, "!");

    printf("\nNome: %s\n", copia);
    printf("Quantidade de caracteres: %zu\n", strlen(nome));

    if (strcmp(curso, "CC") == 0) {
        printf("Curso: Ciencia da Computacao\n");
    } else if (strcmp(curso, "SI") == 0) {
        printf("Curso: Sistemas de Informacao\n");
    } else {
        printf("Curso invalido\n");
    }

    printf("%s\n", mensagem);

    return 0;
}