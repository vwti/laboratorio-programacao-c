#include <stdio.h>
#include <string.h>

int main(void) {
    char nome[50], confirmacao[50];
    char perfil[20];
    char mensagem[100] = "Bem-vindo, ";

    printf("Digite seu primeiro nome: ");
    scanf("%49s", nome);

    printf("Digite o perfil (ADMIN ou COMUM): ");
    scanf("%19s", perfil);

    strcpy(confirmacao, nome);
    strcat(mensagem, nome);

    printf("\nNome: %s\n", confirmacao);
    printf("Quantidade de caracteres: %zu\n", strlen(nome));

    if (strcmp(perfil, "ADMIN") == 0) {
        printf("Perfil: Administrador\n");
    } else if (strcmp(perfil, "COMUM") == 0) {
        printf("Perfil: Usuario comum\n");
    } else {
        printf("Perfil invalido\n");
    }

    printf("%s!\n", mensagem);

    return 0;
}