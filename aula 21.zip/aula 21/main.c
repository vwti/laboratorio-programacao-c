#include <stdio.h>

int main() {
    FILE *arquivo;
    char nome[50];
    int matricula, i;

    arquivo = fopen("funcionarios.txt", "w");

    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo!");
        return 1;
    }

    for (i = 0; i < 5; i++) {
        printf("Digite o nome do funcionario: ");
        scanf(" %[^\n]", nome);

        printf("Digite a matricula: ");
        scanf("%d", &matricula);

        fprintf(arquivo, "Nome: %s | Matricula: %d\n",
                nome, matricula);
    }

    fclose(arquivo);

    printf("\nDados gravados com sucesso!");

    return 0;
}
